
Fuel Up With ATM - Phase 1 (Sketchware Pro Project)

Includes:
- Firebase Email/Password Login
- Real-time Chat using Firebase Realtime Database
- WebView for atmgenerations.blogspot.com

Instructions:
1. Open Sketchware Pro and import 'FuelUpWithATM_Phase1.sketch'
2. Set your Firebase Database URL in FirebaseDB1 component.
3. Enable Email/Password auth in Firebase Authentication settings.
4. Load and test the app on your device.

By ATM Generations
